#ifndef EXN04DETECTORHIT_HH
#define EXN04DETECTORHIT_HH

#include "G4THitsCollection.hh"
#include "G4VHit.hh"
#include "G4Types.hh"

#include <vector>


class ExN04DetectorHit : public G4VHit {
public:
  ExN04DetectorHit();
  ~ExN04DetectorHit(){};
  /// Draw pixels
  void Draw();
  ///// Get hit ID calculated as 1000 * sensorID + cellID
  //G4int ID() { return 1000 * fCopyNumSensor + fCopyNumCell; }
  inline void SetPosition(G4double x, G4double y, G4double z) {
    fPosX = x;
    fPosY = y;
    fPosZ = z;
  }

  inline void SetPDGID(G4int pdgid){
    fPDGID = pdgid;
  }

  /// Get hit X position
  inline G4double GetX() const { return fPosX; }
  /// Get hit Y position
  inline G4double GetY() const { return fPosY; }
  /// Get hit Z position
  inline G4double GetZ() const { return fPosZ; }
/// Get hit pdgID
  inline G4double GetPDGID() const { return fPDGID; }

private:
  /// Position along x axis
  G4double fPosX = -1;
  /// Position along y axis
  G4double fPosY = -1;
  /// Position along z axis
  G4double fPosZ = -1;
  /// PDGID
  G4int fPDGID = -999;

};

typedef G4THitsCollection<ExN04DetectorHit> ExN04DetectorHitCollection;

#endif /* EXN04DETECTORHIT_HH */
